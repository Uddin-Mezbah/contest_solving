#include<stdio.h>

int main()
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);

    int person_1 = a+b;
    int person_2 = a+b;
    int person_3 = b+c;

    if(person_1 < person_2 && person_1 < person_3){
        printf("%d",person_1);
    }
    else if(person_2 < person_1 && person_2 < person_3){
        printf("%d",person_2);
    }
    else{
        printf("%d",person_3);
    }


    return 0;
}


