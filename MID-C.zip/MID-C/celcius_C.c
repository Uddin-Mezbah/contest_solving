#include<stdio.h>

int main()
{

    int n;
    scanf("%d",&n);

    int calculate = 0;

    for (int i = 1; i <= n; i++)
    {

        int temp;
        scanf("%d",&temp);
        if(temp <0)
        {
            calculate=+1;
        }
    }
    printf("%d",calculate);




}
